﻿namespace Switch_simulator
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            currentTime = System.DateTime.Now;         
            this.components = new System.ComponentModel.Container();
            this.label_RemoteIP = new System.Windows.Forms.Label();
            this.label_RemotePort = new System.Windows.Forms.Label();
            this.textBox_RemoteIP = new System.Windows.Forms.TextBox();
            this.textBox_RemotePort = new System.Windows.Forms.TextBox();
            this.button_Connect = new System.Windows.Forms.Button();
            this.button_Disconnect = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox_Synchronisation = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Button_test = new System.Windows.Forms.Button();
            this.button_Send = new System.Windows.Forms.Button();
            this.textBox_Send_telegram = new System.Windows.Forms.TextBox();
            this.label_Send_log = new System.Windows.Forms.Label();
            this.lblError = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.listBox_Send = new System.Windows.Forms.ListBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // label_RemoteIP
            // 
            this.label_RemoteIP.AutoSize = true;
            this.label_RemoteIP.Location = new System.Drawing.Point(22, 25);
            this.label_RemoteIP.Name = "label_RemoteIP";
            this.label_RemoteIP.Size = new System.Drawing.Size(65, 12);
            this.label_RemoteIP.TabIndex = 0;
            this.label_RemoteIP.Text = "Remote IP:";
            // 
            // label_RemotePort
            // 
            this.label_RemotePort.AutoSize = true;
            this.label_RemotePort.Location = new System.Drawing.Point(22, 52);
            this.label_RemotePort.Name = "label_RemotePort";
            this.label_RemotePort.Size = new System.Drawing.Size(77, 12);
            this.label_RemotePort.TabIndex = 0;
            this.label_RemotePort.Text = "Remote Port:";
            // 
            // textBox_RemoteIP
            // 
            this.textBox_RemoteIP.Location = new System.Drawing.Point(115, 22);
            this.textBox_RemoteIP.Name = "textBox_RemoteIP";
            this.textBox_RemoteIP.Size = new System.Drawing.Size(105, 21);
            this.textBox_RemoteIP.TabIndex = 1;
            this.textBox_RemoteIP.Text = "172.20.41.146";
            // 
            // textBox_RemotePort
            // 
            this.textBox_RemotePort.Location = new System.Drawing.Point(115, 49);
            this.textBox_RemotePort.Name = "textBox_RemotePort";
            this.textBox_RemotePort.Size = new System.Drawing.Size(105, 21);
            this.textBox_RemotePort.TabIndex = 1;
            this.textBox_RemotePort.Text = "5002";
            // 
            // button_Connect
            // 
            this.button_Connect.Location = new System.Drawing.Point(24, 88);
            this.button_Connect.Name = "button_Connect";
            this.button_Connect.Size = new System.Drawing.Size(75, 23);
            this.button_Connect.TabIndex = 2;
            this.button_Connect.Text = "Connect";
            this.button_Connect.UseVisualStyleBackColor = true;
            this.button_Connect.Click += new System.EventHandler(this.button_Connect_Click);
            // 
            // button_Disconnect
            // 
            this.button_Disconnect.Location = new System.Drawing.Point(125, 88);
            this.button_Disconnect.Name = "button_Disconnect";
            this.button_Disconnect.Size = new System.Drawing.Size(75, 23);
            this.button_Disconnect.TabIndex = 2;
            this.button_Disconnect.Text = "Disconnect";
            this.button_Disconnect.UseVisualStyleBackColor = true;
            this.button_Disconnect.Click += new System.EventHandler(this.button_Disconnect_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(16, 10);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(103, 48);
            this.button1.TabIndex = 2;
            this.button1.Text = "Synchronisation";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox_Synchronisation
            // 
            this.textBox_Synchronisation.Enabled = false;
            this.textBox_Synchronisation.Location = new System.Drawing.Point(187, 25);
            this.textBox_Synchronisation.Name = "textBox_Synchronisation";
            this.textBox_Synchronisation.Size = new System.Drawing.Size(128, 21);
            this.textBox_Synchronisation.TabIndex = 1;
            this.textBox_Synchronisation.Text = "000000020NRSSYNRR280";
            this.textBox_Synchronisation.Visible = false;
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(238, 126);
            this.panel1.TabIndex = 4;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.Button_test);
            this.panel2.Controls.Add(this.button_Send);
            this.panel2.Controls.Add(this.textBox_Send_telegram);
            this.panel2.Controls.Add(this.textBox_Synchronisation);
            this.panel2.Controls.Add(this.button1);
            this.panel2.Location = new System.Drawing.Point(256, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(848, 126);
            this.panel2.TabIndex = 5;
            // 
            // Button_test
            // 
            this.Button_test.Location = new System.Drawing.Point(143, 10);
            this.Button_test.Name = "Button_test";
            this.Button_test.Size = new System.Drawing.Size(702, 48);
            this.Button_test.TabIndex = 7;
            this.Button_test.Text = "Refresh";
            this.Button_test.UseVisualStyleBackColor = true;
            this.Button_test.Click += new System.EventHandler(this.Button_test_Click);
            // 
            // button_Send
            // 
            this.button_Send.Location = new System.Drawing.Point(16, 71);
            this.button_Send.Name = "button_Send";
            this.button_Send.Size = new System.Drawing.Size(103, 52);
            this.button_Send.TabIndex = 6;
            this.button_Send.Text = "Send";
            this.button_Send.UseVisualStyleBackColor = true;
            this.button_Send.Click += new System.EventHandler(this.button_Send_Click);
            // 
            // textBox_Send_telegram
            // 
            this.textBox_Send_telegram.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox_Send_telegram.Location = new System.Drawing.Point(143, 71);
            this.textBox_Send_telegram.Multiline = true;
            this.textBox_Send_telegram.Name = "textBox_Send_telegram";
            this.textBox_Send_telegram.Size = new System.Drawing.Size(702, 52);
            this.textBox_Send_telegram.TabIndex = 6;
            this.textBox_Send_telegram.Text = "Send_telegram";
            // 
            // label_Send_log
            // 
            this.label_Send_log.AutoSize = true;
            this.label_Send_log.Location = new System.Drawing.Point(12, 157);
            this.label_Send_log.Name = "label_Send_log";
            this.label_Send_log.Size = new System.Drawing.Size(107, 12);
            this.label_Send_log.TabIndex = 2;
            this.label_Send_log.Text = "Communication_log";
            // 
            // lblError
            // 
            this.lblError.AutoSize = true;
            this.lblError.Location = new System.Drawing.Point(95, 502);
            this.lblError.Name = "lblError";
            this.lblError.Size = new System.Drawing.Size(47, 12);
            this.lblError.TabIndex = 1;
            this.lblError.Text = "Status:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(20, 502);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 12);
            this.label1.TabIndex = 8;
            this.label1.Text = "Status:";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // listBox_Send
            // 
            this.listBox_Send.FormattingEnabled = true;
            this.listBox_Send.HorizontalScrollbar = true;
            this.listBox_Send.ItemHeight = 12;
            this.listBox_Send.Location = new System.Drawing.Point(3, 15);
            this.listBox_Send.Name = "listBox_Send";
            this.listBox_Send.Size = new System.Drawing.Size(1086, 316);
            this.listBox_Send.TabIndex = 4;
            this.listBox_Send.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listBox_Send_MouseDoubleClick);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.listBox_Send);
            this.panel4.Location = new System.Drawing.Point(12, 157);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1092, 342);
            this.panel4.TabIndex = 7;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1116, 523);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label_Send_log);
            this.Controls.Add(this.lblError);
            this.Controls.Add(this.button_Disconnect);
            this.Controls.Add(this.button_Connect);
            this.Controls.Add(this.textBox_RemotePort);
            this.Controls.Add(this.textBox_RemoteIP);
            this.Controls.Add(this.label_RemotePort);
            this.Controls.Add(this.label_RemoteIP);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel4);
            this.Name = "Form1";
            this.Text = "Switch_Simulator";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_RemoteIP;
        private System.Windows.Forms.Label label_RemotePort;
        private System.Windows.Forms.TextBox textBox_RemoteIP;
        private System.Windows.Forms.TextBox textBox_RemotePort;
        private System.Windows.Forms.Button button_Connect;
        private System.Windows.Forms.Button button_Disconnect;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox_Synchronisation;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox textBox_Send_telegram;
        private System.Windows.Forms.Button button_Send;
        private System.Windows.Forms.Label label_Send_log;
        private System.Windows.Forms.Label lblError;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button Button_test;
        private System.Windows.Forms.ListBox listBox_Send;
        private System.Windows.Forms.Panel panel4;
    }
}

