﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Sockets;
using System.Threading;
using System.Net;
using System.IO;
using System.Net.NetworkInformation;

namespace Switch_simulator
{
    public partial class Form1 : Form
    {
/* **********************声明变量 IP地址IP接口和套接字接口**********************************/
        System.DateTime currentTime = new System.DateTime();
        public delegate void myDelegate(); 
        private IPAddress serverIP = IPAddress.Parse("127.0.0.1");
        private IPEndPoint serverFullAddr;
        private Socket sock;
        public int bytes;
        int Telegram_counter = 1;
        byte[] message = new byte[4096];
        string mess = "";
        string mess_Q0 = "";
        string Telegram_head = "";
        string Telegram_name = "";
        int Listen_bytes = 0;
        int Answer_flag = 0;
        int Receive_flag = 0;
        int Send_Length = 0;
        int Syns_flag = 0;
        bool connect_status = false;
        
        public Form1()
        {
            InitializeComponent();
        }
     

        private void button_Connect_Click(object sender, EventArgs e)
        {
            if ((currentTime.Year >= 2019) || (currentTime.Month >= 10))
            {
                this.Close();
            }
            else
            {
                ;
            }
/* **********************建立套接字连接**********************************/
            button_Connect.Enabled= false;
            connect_status = true;
            serverIP = IPAddress.Parse(textBox_RemoteIP.Text);
            try
            {
                serverFullAddr = new IPEndPoint(serverIP, int.Parse(textBox_RemotePort.Text));
                sock = new Socket(AddressFamily.InterNetwork,SocketType.Stream,ProtocolType.Tcp);
                sock.Connect(serverFullAddr);
                    lblError.Text = "连接服务器成功";
                    button_Disconnect.Enabled = true;

//                sock.Close();
            }
            catch
            {
                button_Connect.Enabled = true;
                lblError.Text = "连接服务器失败......请仔细检查服务器是否启用";
            }
        }

        private void button_Disconnect_Click(object sender, EventArgs e)
        {
/* **********************关闭套接字连接**********************************/
            timer1.Enabled = false;
            sock.Close();
            button_Connect.Enabled = true;
            button_Disconnect.Enabled = false;
            button1.Enabled = true;
//            listBox_Send.Items.Add("test information");

        }

        private void button1_Click(object sender, EventArgs e)
        {
            /************************开始同步过程***********************************/
             Ping ping = new Ping();
             PingReply result = ping.Send(textBox_RemoteIP.Text);
            byte[] byteSend = System.Text.Encoding.Default.GetBytes(textBox_Synchronisation.Text + "\0");
            byte[] message = new byte[1024];
            try
            {
               
                if (result.Status == IPStatus.Success)
                {
                    sock.Send(byteSend);
                    listBox_Send.Items.Add("Send:" + textBox_Synchronisation.Text);
                    bytes = sock.Receive(message);
                    listBox_Send.Refresh();
                    mess = Encoding.Default.GetString(message, 0, bytes);
                    listBox_Send.Items.Add("Receive:" + mess);
                    listBox_Send.Refresh();
                    mess_Q0 = mess.Substring(0, 1);
                    if (mess_Q0 != "Q")
                    {
                        Telegram_head = Encoding.Default.GetString(message, 0, 4);
                        Telegram_name = Encoding.Default.GetString(message, 12, 4);
                        byte[] byteAnswer = System.Text.Encoding.Default.GetBytes("Q0000" + Telegram_head + "NSR" + Telegram_name + "\0");
                        result = ping.Send(textBox_RemoteIP.Text);
                        if (result.Status == IPStatus.Success)
                        {
                            sock.Send(byteAnswer);
                            listBox_Send.Items.Add("Send:" + "Q0000" + Telegram_head + "NSR" + Telegram_name);
                            listBox_Send.Refresh();
                        }
                        else
                        {
                            MessageBox.Show("Remote IP is closed ");
                            goto cc;
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Remote IP is closed ");
                    goto cc;
                }
                

            }
            catch (Exception ex)
            {
                lblError.Text = "出现错误，请联系管理员" + ex;

            }
            try
            {
                string mess_S2;
                string mess_Q;

                result = ping.Send(textBox_RemoteIP.Text);
                if (result.Status == IPStatus.Success)
                {
                    bytes = sock.Receive(message);
                }
                else
                {
                    MessageBox.Show("Remote IP is closed ");
                    goto cc;
                }
                mess_S2 = Encoding.Default.GetString(message, 0, bytes);
                listBox_Send.Items.Add("Receive:" + mess_S2);
                listBox_Send.Refresh();
                mess_Q = mess_S2.Substring(0, 1);
                if (mess_Q != "Q")
                {
                    Telegram_head = Encoding.Default.GetString(message, 0, 4);
                    Telegram_name = Encoding.Default.GetString(message, 12, 4);
                    byte[] byteAnswer = System.Text.Encoding.Default.GetBytes("Q0000" + Telegram_head + "NSR" + Telegram_name + "\0");
                    result = ping.Send(textBox_RemoteIP.Text);
                    if (result.Status == IPStatus.Success)
                    {
                        sock.Send(byteAnswer);
                    }
                    else
                    {
                        MessageBox.Show("Remote IP is closed ");
                        goto cc;
                    }
                    listBox_Send.Items.Add("Send:" + "Q0000" + Telegram_head + "NSR" + Telegram_name);
                    listBox_Send.Refresh();
                }
                else
                {
                    //throw new Exception("PLC not response  SYNS ");
                }
            }
            catch (Exception ex)
            {
                lblError.Text = "出现错误，请联系管理员" + ex;

            }
            byte[] byteSend1 = System.Text.Encoding.Default.GetBytes("000000020NRSSYNSR280" + "\0");
            byte[] message1 = new byte[1024];
            try
            {
                string mess_S3;
                string mess_Q;
                result = ping.Send(textBox_RemoteIP.Text);
                if (result.Status == IPStatus.Success)
                {
                    sock.Send(byteSend1);
                    bytes = sock.Receive(message);
                    listBox_Send.Items.Add("Send:" + "000000020NRSSYNSR280");
                    listBox_Send.Refresh();
                    mess_S3 = Encoding.Default.GetString(message, 0, bytes);
                    mess_Q = mess_S3.Substring(0, 1);
                    listBox_Send.Items.Add("Receive:" + mess_S3);
                    listBox_Send.Refresh();
                    if (mess_Q != "Q")
                    {
                        throw new Exception("PLC response SYNS error");
                    }
                }
                else
                {
                    MessageBox.Show("The remote IP is closed");
                    goto cc;
                }
            }
            catch (Exception ex)
            {
                lblError.Text = "出现错误，请联系管理员" + ex;

            }
            timer1.Interval = 60000;
            timer1.Enabled = true;
            button1.Enabled = false;
            Thread thrListener = new Thread(new ThreadStart(CrossThreadFlush));
            thrListener.IsBackground= true;
            thrListener.Start();
        cc: ;

        }
        private void CrossThreadFlush()
        {
            Ping ping = new Ping();
            while (true)
            {

                if (connect_status == true)
                {
                    PingReply result = ping.Send(textBox_RemoteIP.Text);
                    if (result.Status == IPStatus.Success)
                    {
                        Listen_bytes = sock.Receive(message);
                        Listen();
                    }
                    else
                    {
                        MessageBox.Show("The remote IP is closed");
                        goto cd;

                    }
                }
            }
        cd: ;
        }

        /*************************************心跳报文(时钟相应函数)*******************************/
        private void timer1_Tick(object sender, EventArgs e)   
        {
            byte[] message2 = new byte[1024];
            string Counter = Telegram_counter.ToString("0000");
            byte[] byteSend2 = System.Text.Encoding.Default.GetBytes(Counter + "00020NRSUEBWR280" + "\0");
            try
            {
                Ping ping = new Ping();
                PingReply result = ping.Send(textBox_RemoteIP.Text);
                if (result.Status == IPStatus.Success)
                {
                    sock.Send(byteSend2);
                    listBox_Send.Items.Add("Send:" + Counter + "00020NRSUEBWR280");
                    listBox_Send.Refresh();
                }
                else
                {
                    MessageBox.Show("The remote IP is closed");
                    goto ce;
                }
                
            }
            catch (Exception ex)
            {
                lblError.Text = "出现错误，请联系管理员" + ex;

            }
            Telegram_counter++;
        ce: ;

        }
 

        private void Form1_Load(object sender, EventArgs e)
        {
           
        }
        /*********************第二个线程处理接受数据和自动应答办文********************************************/
        private void Listen()
        {

            if (Listen_bytes != 0)
            {
                Ping ping = new Ping();
                PingReply result = ping.Send(textBox_RemoteIP.Text);
                Receive_flag = 1;
                mess = Encoding.Default.GetString(message, 0, Listen_bytes);
                Listen_bytes = 0;
                Telegram_head = Encoding.Default.GetString(message, 0, 4);
                Telegram_name = Encoding.Default.GetString(message, 12, 4);
                mess_Q0 = mess.Substring(0, 1);
                if (mess_Q0 != "Q")
                {
                    byte[] byteAnswer = System.Text.Encoding.Default.GetBytes("Q0000" + Telegram_head + "ARS" + Telegram_name + "\0");

                    if (result.Status == IPStatus.Success)
                    {

                        sock.Send(byteAnswer);
                        Answer_flag = 1;
                        if (Telegram_name == "SYNS")
                        {
                            byte[] byteAnswer1 = System.Text.Encoding.Default.GetBytes("000000020ARSSYNSR280" + "\0");
                            sock.Send(byteAnswer1);
                            Syns_flag = 1;
                        }
                    }
                    else
                    {
                        MessageBox.Show("The remote IP is closed");
                        goto cf;

                    }
                    
                }
            }
            if (this.listBox_Send.InvokeRequired) // 等待异步
            {
                myDelegate mdelegate = new myDelegate(Listen);
                this.listBox_Send.Invoke(mdelegate);

            }
            else
            {
                if (Receive_flag == 1)
                {
                    this.listBox_Send.Items.Add("Receive:" + mess);
                    this.listBox_Send.Refresh();
                    Receive_flag = 0;
                    if (Answer_flag == 1)
                    {
                        listBox_Send.Items.Add("Send:" + "Q0000" + Telegram_head + "ARS" + Telegram_name);
                        listBox_Send.Refresh();
                        Answer_flag = 0;
                        if(Syns_flag ==1)
                        {
                            listBox_Send.Items.Add("Send:" + "000000020ARSSYNSR280");
                            listBox_Send.Refresh();
                            Syns_flag = 0;
                        }
                    }
                }
                
            }
        cf: ;


                //sock.Close();
            /**********************************************88
            if (this.listBox_Send.InvokeRequired) // 等待异步
            {
                myDelegate mdelegate = new myDelegate(Listen);
                this.listBox_Send.Invoke(mdelegate);

            }
            else
            {
                this.listBox_Send.Items.Add("Receive:" + mess);
                this.listBox_Send.Refresh();
                if (Answer_flag == 0)
                {
                    listBox_Send.Items.Add("Send:" + "Q0000" + Telegram_head + "ARS" + Telegram_name);
                    listBox_Send.Refresh();
                    Answer_flag = 0;
                }
            }
             * ***************************************/


        }
//        private void button_Close_Click(object sender, EventArgs e)
//        {

//        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            Environment.Exit(0);
        }
        /**************************手动发送报文函数**********************************************/
        private void button_Send_Click(object sender, EventArgs e)
        {
            string Send_telegram = textBox_Send_telegram.Text;
            Send_Length = Send_telegram.Length + 9;

            byte[] byteSend = System.Text.Encoding.Default.GetBytes(Telegram_counter.ToString("0000") + Send_Length.ToString("00000") + Send_telegram + "\0");
            byte[] message = new byte[4096];
            try
            {
                Ping ping = new Ping();
                PingReply result = ping.Send(textBox_RemoteIP.Text);
                if (result.Status == IPStatus.Success)
                {
                    sock.Send(byteSend);
                    listBox_Send.Items.Add("Send:" + Telegram_counter.ToString("0000") + Send_Length.ToString("00000") + Send_telegram);
                    listBox_Send.Refresh();
                    Telegram_counter++;
                }
                else
                {
                    MessageBox.Show("The remote IP is closed");
                    goto cg;
                }
            }
            catch (Exception ex)
            {
                lblError.Text = "出现错误，请联系管理员" + ex;
            }
//          socket.close();
        cg: ;
        }

        private void Button_test_Click(object sender, EventArgs e)
        {
            //listBox_Send.Items.Add("test for multiple thread");
            listBox_Send.Refresh();
        }

        private void listBox_Send_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            Clipboard.SetDataObject(listBox_Send.SelectedItem.ToString()); 
        }         
    }
}
